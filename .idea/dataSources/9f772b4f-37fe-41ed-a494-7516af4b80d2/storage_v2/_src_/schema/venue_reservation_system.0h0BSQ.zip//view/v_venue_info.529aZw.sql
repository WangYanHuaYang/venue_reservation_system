create definer = root@`%` view v_venue_info as
select `v`.`id`                 AS `id`,
       `v`.`venue_name`         AS `venue_name`,
       `dp`.`dictionaries_name` AS `province`,
       `dc`.`dictionaries_name` AS `city`,
       `dd`.`dictionaries_name` AS `district`,
       `v`.`address`            AS `address`,
       `v`.`longitude`          AS `longitude`,
       `v`.`latitude`           AS `latitude`,
       `v`.`area`               AS `area`,
       `v`.`number_of_persons`  AS `number_of_persons`,
       `ds`.`dictionaries_name` AS `school_name`,
       `v`.`venue_project`      AS `venue_project`,
       `v`.`suitable_crowd`     AS `suitable_crowd`,
       `v`.`open_time`          AS `open_time`,
       `v`.`close_time`         AS `close_time`,
       `v`.`remarks`            AS `remarks`,
       `v`.`lunch_start_time`   AS `lunch_start_time`,
       `v`.`lunch_end_time`     AS `lunch_end_time`,
       `v`.`time_period`        AS `time_period`,
       `v`.`rest_time`          AS `rest_time`,
       `v`.`audit_status`       AS `audit_status`,
       `sc`.`user_name`         AS `create_user_id`,
       `sa`.`user_name`         AS `audit_user_id`,
       `v`.`venue_phone_number` AS `venue_phone_number`,
       `v`.`create_time`        AS `create_time`,
       `v`.`update_time`        AS `update_time`,
       `v`.`del_state`          AS `del_state`,
       `v`.`reserve1`           AS `reserve1`,
       `v`.`reserve2`           AS `reserve2`,
       `v`.`reserve3`           AS `reserve3`,
       `v`.`reserve4`           AS `reserve4`,
       `v`.`reserve5`           AS `reserve5`
from ((((((`venue_reservation_system`.`venue` `v` left join `venue_reservation_system`.`dictionaries` `dp` on ((`dp`.`id` = `v`.`province`))) left join `venue_reservation_system`.`dictionaries` `dc` on ((`dc`.`id` = `v`.`city`))) left join `venue_reservation_system`.`dictionaries` `dd` on ((`dd`.`id` = `v`.`district`))) left join `venue_reservation_system`.`dictionaries` `ds` on ((`ds`.`id` = `v`.`school_name`))) left join `venue_reservation_system`.`sys_user` `sc` on ((`sc`.`id` = `v`.`create_user_id`)))
         left join `venue_reservation_system`.`sys_user` `sa` on ((`sa`.`id` = `v`.`audit_user_id`)));

-- comment on column v_venue_info.id not supported: id

-- comment on column v_venue_info.venue_name not supported: 场馆名称

-- comment on column v_venue_info.province not supported: 字典名称

-- comment on column v_venue_info.city not supported: 字典名称

-- comment on column v_venue_info.district not supported: 字典名称

-- comment on column v_venue_info.address not supported: 详细地址

-- comment on column v_venue_info.longitude not supported: 经度

-- comment on column v_venue_info.latitude not supported: 纬度

-- comment on column v_venue_info.area not supported: 场馆面积

-- comment on column v_venue_info.number_of_persons not supported: 可容纳人数

-- comment on column v_venue_info.school_name not supported: 字典名称

-- comment on column v_venue_info.venue_project not supported: 场馆项目

-- comment on column v_venue_info.suitable_crowd not supported: 适宜人群

-- comment on column v_venue_info.open_time not supported: 开馆时间

-- comment on column v_venue_info.close_time not supported: 闭馆时间

-- comment on column v_venue_info.remarks not supported: 备注

-- comment on column v_venue_info.lunch_start_time not supported: 午休开始时间

-- comment on column v_venue_info.lunch_end_time not supported: 午休结束时间

-- comment on column v_venue_info.time_period not supported: 单次时间段 单位：小时

-- comment on column v_venue_info.rest_time not supported: 单次间隔时间 单位：分

-- comment on column v_venue_info.audit_status not supported: 审核状态 0_未提交 1_待审核 2_审核通过

-- comment on column v_venue_info.create_user_id not supported: 用户名

-- comment on column v_venue_info.audit_user_id not supported: 用户名

-- comment on column v_venue_info.venue_phone_number not supported: 场馆电话

-- comment on column v_venue_info.create_time not supported: 创建时间

-- comment on column v_venue_info.update_time not supported: 更新时间

-- comment on column v_venue_info.del_state not supported: 删除状态 0_删除 1_未删除

-- comment on column v_venue_info.reserve1 not supported: 场馆制度

-- comment on column v_venue_info.reserve2 not supported: 场馆区域划分

-- comment on column v_venue_info.reserve3 not supported: 场馆简介

-- comment on column v_venue_info.reserve4 not supported: 轮播图

-- comment on column v_venue_info.reserve5 not supported: 平面图

