create definer = root@`%` view v_attachment_venue as
select `ven`.`id`                                                        AS `id`,
       `ven`.`venue_name`                                                AS `venue_name`,
       `ven`.`province`                                                  AS `province`,
       `ven`.`city`                                                      AS `city`,
       `ven`.`district`                                                  AS `district`,
       `ven`.`address`                                                   AS `address`,
       `ven`.`longitude`                                                 AS `longitude`,
       `ven`.`latitude`                                                  AS `latitude`,
       `ven`.`area`                                                      AS `area`,
       `ven`.`number_of_persons`                                         AS `number_of_persons`,
       `ven`.`school_name`                                               AS `school_name`,
       `ven`.`venue_project`                                             AS `venue_project`,
       `ven`.`suitable_crowd`                                            AS `suitable_crowd`,
       `ven`.`open_time`                                                 AS `open_time`,
       `ven`.`close_time`                                                AS `close_time`,
       `ven`.`remarks`                                                   AS `remarks`,
       `ven`.`lunch_start_time`                                          AS `lunch_start_time`,
       `ven`.`lunch_end_time`                                            AS `lunch_end_time`,
       `ven`.`time_period`                                               AS `time_period`,
       `ven`.`rest_time`                                                 AS `rest_time`,
       `ven`.`audit_status`                                              AS `audit_status`,
       `ven`.`create_user_id`                                            AS `create_user_id`,
       `ven`.`audit_user_id`                                             AS `audit_user_id`,
       `ven`.`create_time`                                               AS `create_time`,
       `ven`.`update_time`                                               AS `update_time`,
       `ven`.`del_state`                                                 AS `del_state`,
       `ven`.`reserve1`                                                  AS `reserve1`,
       `ven`.`reserve2`                                                  AS `reserve2`,
       `ven`.`reserve3`                                                  AS `reserve3`,
       `ven`.`reserve4`                                                  AS `reserve4`,
       `ven`.`reserve5`                                                  AS `reserve5`,
       `venue_reservation_system`.`appointment`.`start_time`             AS `start_time`,
       `venue_reservation_system`.`appointment`.`end_time`               AS `end_time`,
       sum(`venue_reservation_system`.`appointment`.`number_of_persons`) AS `now_number`
from (`venue_reservation_system`.`appointment`
         left join `venue_reservation_system`.`v_venue_info` `ven`
                   on (((`venue_reservation_system`.`appointment`.`venue_id` = `ven`.`id`) and
                        (`ven`.`del_state` = 1) and (`ven`.`audit_status` = 2))))
where ((`venue_reservation_system`.`appointment`.`del_state` = 1) and
       (`venue_reservation_system`.`appointment`.`audit_status` = 2))
group by `venue_reservation_system`.`appointment`.`venue_id`, `venue_reservation_system`.`appointment`.`end_time`,
         `venue_reservation_system`.`appointment`.`start_time`;

-- comment on column v_attachment_venue.id not supported: id

-- comment on column v_attachment_venue.venue_name not supported: 场馆名称

-- comment on column v_attachment_venue.province not supported: 字典名称

-- comment on column v_attachment_venue.city not supported: 字典名称

-- comment on column v_attachment_venue.district not supported: 字典名称

-- comment on column v_attachment_venue.address not supported: 详细地址

-- comment on column v_attachment_venue.longitude not supported: 经度

-- comment on column v_attachment_venue.latitude not supported: 纬度

-- comment on column v_attachment_venue.area not supported: 场馆面积

-- comment on column v_attachment_venue.number_of_persons not supported: 可容纳人数

-- comment on column v_attachment_venue.school_name not supported: 字典名称

-- comment on column v_attachment_venue.venue_project not supported: 场馆项目

-- comment on column v_attachment_venue.suitable_crowd not supported: 适宜人群

-- comment on column v_attachment_venue.open_time not supported: 开馆时间

-- comment on column v_attachment_venue.close_time not supported: 闭馆时间

-- comment on column v_attachment_venue.remarks not supported: 备注

-- comment on column v_attachment_venue.lunch_start_time not supported: 午休开始时间

-- comment on column v_attachment_venue.lunch_end_time not supported: 午休结束时间

-- comment on column v_attachment_venue.time_period not supported: 单次时间段 单位：小时

-- comment on column v_attachment_venue.rest_time not supported: 单次间隔时间 单位：分

-- comment on column v_attachment_venue.audit_status not supported: 审核状态 0_未提交 1_待审核 2_审核通过

-- comment on column v_attachment_venue.create_user_id not supported: 用户名

-- comment on column v_attachment_venue.audit_user_id not supported: 用户名

-- comment on column v_attachment_venue.create_time not supported: 创建时间

-- comment on column v_attachment_venue.update_time not supported: 更新时间

-- comment on column v_attachment_venue.del_state not supported: 删除状态 0_删除 1_未删除

-- comment on column v_attachment_venue.reserve1 not supported: 场馆制度

-- comment on column v_attachment_venue.reserve2 not supported: 场馆区域划分

-- comment on column v_attachment_venue.reserve3 not supported: 场馆简介

-- comment on column v_attachment_venue.reserve4 not supported: 轮播图

-- comment on column v_attachment_venue.reserve5 not supported: 平面图

-- comment on column v_attachment_venue.start_time not supported: 预约开始时间

-- comment on column v_attachment_venue.end_time not supported: 预约结束时间

