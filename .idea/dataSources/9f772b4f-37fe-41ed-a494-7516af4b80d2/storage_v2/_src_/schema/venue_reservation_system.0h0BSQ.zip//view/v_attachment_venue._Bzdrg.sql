create definer = root@`%` view v_attachment_venue as
select `ven`.`venue_name`                                                AS `venue_name`,
       `ven`.`school_name`                                               AS `school_name`,
       `ven`.`province`                                                  AS `province`,
       `ven`.`city`                                                      AS `city`,
       `ven`.`district`                                                  AS `district`,
       `ven`.`address`                                                   AS `address`,
       `ven`.`longitude`                                                 AS `longitude`,
       `ven`.`latitude`                                                  AS `latitude`,
       `ven`.`venue_project`                                             AS `venue_project`,
       `ven`.`area`                                                      AS `area`,
       `ven`.`suitable_crowd`                                            AS `suitable_crowd`,
       `ven`.`open_time`                                                 AS `open_time`,
       `ven`.`close_time`                                                AS `close_time`,
       `venue_reservation_system`.`appointment`.`start_time`             AS `start_time`,
       `venue_reservation_system`.`appointment`.`end_time`               AS `end_time`,
       `ven`.`max_persons`                                               AS `max_persons`,
       sum(`venue_reservation_system`.`appointment`.`number_of_persons`) AS `number_of_persons`
from (`venue_reservation_system`.`appointment`
         left join (select `v`.`id`                 AS `id`,
                           `v`.`venue_name`         AS `venue_name`,
                           `v`.`school_name`        AS `school_name`,
                           `v`.`address`            AS `address`,
                           `v`.`longitude`          AS `longitude`,
                           `v`.`latitude`           AS `latitude`,
                           `v`.`number_of_persons`  AS `max_persons`,
                           `v`.`area`               AS `area`,
                           `v`.`venue_project`      AS `venue_project`,
                           `v`.`suitable_crowd`     AS `suitable_crowd`,
                           `v`.`open_time`          AS `open_time`,
                           `v`.`close_time`         AS `close_time`,
                           `dp`.`dictionaries_name` AS `province`,
                           `dc`.`dictionaries_name` AS `city`,
                           `dd`.`dictionaries_name` AS `district`
                    from (((`venue_reservation_system`.`venue` `v` left join `venue_reservation_system`.`dictionaries` `dp` on (((`v`.`province` = `dp`.`id`) and (`dp`.`del_state` = 1)))) left join `venue_reservation_system`.`dictionaries` `dc` on (((`v`.`city` = `dc`.`id`) and (`dp`.`del_state` = 1))))
                             left join `venue_reservation_system`.`dictionaries` `dd`
                                       on (((`v`.`district` = `dd`.`id`) and (`dp`.`del_state` = 1))))
                    where (`v`.`del_state` = 1)) `ven`
                   on ((`venue_reservation_system`.`appointment`.`venue_id` = `ven`.`id`)))
where ((`venue_reservation_system`.`appointment`.`del_state` = 1) and
       (`venue_reservation_system`.`appointment`.`audit_status` = 2))
group by `venue_reservation_system`.`appointment`.`venue_id`, `venue_reservation_system`.`appointment`.`end_time`,
         `venue_reservation_system`.`appointment`.`start_time`;

-- comment on column v_attachment_venue.venue_name not supported: 场馆名称

-- comment on column v_attachment_venue.school_name not supported: 所属学校

-- comment on column v_attachment_venue.province not supported: 字典名称

-- comment on column v_attachment_venue.city not supported: 字典名称

-- comment on column v_attachment_venue.district not supported: 字典名称

-- comment on column v_attachment_venue.address not supported: 详细地址

-- comment on column v_attachment_venue.longitude not supported: 经度

-- comment on column v_attachment_venue.latitude not supported: 纬度

-- comment on column v_attachment_venue.venue_project not supported: 场馆项目

-- comment on column v_attachment_venue.area not supported: 场馆面积

-- comment on column v_attachment_venue.suitable_crowd not supported: 适宜人群

-- comment on column v_attachment_venue.open_time not supported: 开馆时间

-- comment on column v_attachment_venue.close_time not supported: 闭馆时间

-- comment on column v_attachment_venue.start_time not supported: 预约开始时间

-- comment on column v_attachment_venue.end_time not supported: 预约结束时间

-- comment on column v_attachment_venue.max_persons not supported: 可容纳人数

